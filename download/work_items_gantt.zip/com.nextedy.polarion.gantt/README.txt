Nextedy Gantt Charts
=====================

'Work Items Gantt' widget brings the interactive high-level project planning & scheduling to Polarion ALM.

It is extending the Polation Gantt , that is by default showing Polarion Plan items only, with capability to expose the standard Work Items (such as Features, Epics, Objectives, ...). 
 
Licensing: Commercial (see LICENSE.pdf), 30day Evaluation license included in the download. 

Requirements: Polarion 18.0+ 

Installation: See INSTALL.txt 

Author: Nextedy Systems https://www.nextedy.com 
For information about licensing and pricing, please contact us at info@nextedy.com
