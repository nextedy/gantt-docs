For details see - com.nextedy.polarion.gantt/README.txt
Licensing - com.nextedy.polarion.gantt/LICENS.pdf