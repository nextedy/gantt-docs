com.nextedy.polarion.gantt
===========================
Detailed README: com.nextedy.polarion.gantt/README.txt
Installation instructions: com.nextedy.polarion.gantt/INSTALL.txt
Licensing information: com.nextedy.polarion.gantt/LICENSE.pdf

