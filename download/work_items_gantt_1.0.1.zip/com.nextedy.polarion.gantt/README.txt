Work Items Gantt

================


Work Items Gantt brings the interactive high-level project planning & scheduling to Polarion ALM.

It is extending the Polation Gantt , that is by default showing Polarion Plan items only, with capability to expose the standard Work Items (such as Features, Epics, Objectives, ...).



The Work Items Gantt widget is developed by Nextedy Systems https://www.nextedy.com

For information about licensing and pricing, please contact us at info@nextedy.com