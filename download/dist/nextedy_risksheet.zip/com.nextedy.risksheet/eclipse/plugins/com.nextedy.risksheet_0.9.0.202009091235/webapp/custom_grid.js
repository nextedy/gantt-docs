function eXcell_semanticCo(cell){
	if (cell){
		this.cell=cell;
		this.grid=this.cell.parentNode.grid;
		this.combo=(this.cell._combo||this.grid.getCombo(this.cell._cellIndex));
		this.editable=true
	}
	this.edit=function(){
		this.val=this.getValue();
		this.text=this.getText()._dhx_trim();
		var arPos = this.grid.getPosition(this.cell);

		this.obj=document.createElement("input");
		this.obj.className="cellComboInput";

		this.obj.style.height=(this.cell.offsetHeight-(this.grid.multiLine ? 9 : 4))+"px";

		this.obj.wrap="soft";
		this.obj.style.textAlign=this.cell.style.textAlign;
		this.obj.onclick=function(e){
			(e||event).cancelBubble=true
		}
		this.obj.onmousedown=function(e){
			(e||event).cancelBubble=true
		}
		this.obj.value=this.val
		this.obj.onselectstart=function(e){
			if (!e)
				e=event;
			e.cancelBubble=true;
			return true;
		};
		var editor_obj = this;
		
		var comboKeys = this.combo.getKeys();
		this.obj.onkeydown=function(e){
			var key=(e||event).keyCode;
			if (key==13){
				var newVal = editor_obj.obj.value;
				editor_obj.cell.combo_value = newVal;
				
				if (!(newVal in comboKeys)){			
					e.cancelBubble=true;
					return false;
				}
			}
		}
		this.list=document.createElement("div");
		this.list.innerHTML = '<input type="hidden" name="list"></i>';
	
		this.list.className='ui selection dropdown';
		this.list.style.position='absolute';
		this.list.style.width=this.cell.offsetWidth+"px";

		var scrollLeft = this.grid.objBox.scrollLeft;
		var gridWidth = this.grid.obj.offsetWidth;
		
		var xPosition = (scrollLeft+arPos[0]);
		if (xPosition+300>gridWidth){
			xPosition = gridWidth - 300;
		}
		this.list.style.left=xPosition+"px";                       //arPos[0]
		this.list.style.top=this.cell.offsetHeight+"px"; //arPos[1]+this.cell.offsetHeight;
		this.list.onmousedown=function(e){
			var ev = e||window.event;
			var cell = ev.target||ev.srcElement

			if (cell.tagName !== "DIV"){
				cell=cell.parentNode;
			}
			
			var selectedValue = $(cell).attr('data-value');
			if (selectedValue){
				editor_obj.cell.combo_value = selectedValue;
				editor_obj.editable=false;
				editor_obj.grid.editStop();
			}
			ev.cancelBubble = true;
		}
		
		for (var i = 0; i < comboKeys.length; i++){
			var val = this.combo.get(comboKeys[i]);
			var optionEl = document.createElement("div");
			
			$(optionEl).attr('data-value', comboKeys[i]);
			var currentCss="";
			if (editor_obj.obj.value==comboKeys[i]){
				currentCss = ' current';
			}
			//optionEl.innerHTML = val.name+' - <b>'+val.desc+'</b>';
			optionEl.innerHTML = val;
			optionEl.className="item"+currentCss;
			this.list.appendChild(optionEl);
		}

		if (this.editable){
			this.cell.innerHTML="";
		}
		else {
			this.obj.style.width="0px";
			this.obj.style.height="0px";
		}
		this.cell.appendChild(this.obj);
		this.cell.appendChild(this.list);
		
		if (!this.editable){
			this.obj.style.visibility="hidden";
			this.obj.style.position="absolute";			
		}
		
		this.obj.focus();
		this.obj.select();
	}

	this.getValue=function(){
		return ((this.cell.combo_value == window.undefined) ? "" : this.cell.combo_value);
	}
	this.detach=function(){
		if (this.val != this.getValue()){
			this.cell.wasChanged=true;
		}

		this.setValue(this.cell.combo_value)

		if (this.list.parentNode)
			this.list.parentNode.removeChild(this.list);

		if (this.obj.parentNode)
			this.obj.parentNode.removeChild(this.obj);

		return this.val != this.getValue();
	}
}

eXcell_semanticCo.prototype=new eXcell;

eXcell_semanticCo.prototype.getText=function(){
	return this.cell.innerHTML;
}
eXcell_semanticCo.prototype.setValue=function(val){
	if ((val||"").toString()._dhx_trim() == "")
		val=null
	this.cell.combo_value=val;
	
	if (val !== null){
		this.setCValue(val);
	}else{
		this.setCValue("&nbsp;", val);		
	}
}			


function eXcell_rpnColored(cell){ // the eXcell name is defined here
	if (cell){            // the default pattern, just copy it
		this.cell = cell;
		this.grid = this.cell.parentNode.grid;
	}
	this.edit = function(){} //read-only cell doesn't have edit method
	// the cell is read-only, so it's always in the disabled state
	this.isDisabled = function(){ return true; } 
	this.setValue=function(val,row){
		var style = getStyleForRpn(val);
		this.setCValue(""); 
		
		removeRpnClasses(this.cell);
		jQuery(this.cell).addClass(style);
	}
}

eXcell_rpnColored.prototype = new eXcell;

function eXcell_rpn(cell){ // the eXcell name is defined here
	if (cell){            // the default pattern, just copy it
		this.cell = cell;
		this.grid = this.cell.parentNode.grid;
	}
	this.edit = function(){} //read-only cell doesn't have edit method
	// the cell is read-only, so it's always in the disabled state
	this.isDisabled = function(){ return true; } 
	this.setValue=function(val,row){
		var style = getStyleForRpn(val);
		this.setCValue(val); 
		
		removeRpnClasses(this.cell);
		jQuery(this.cell).addClass(style);
	}
}
eXcell_rpn.prototype = new eXcell;		

function setGridComboOptions(colIndex, options){
	var combo = myGrid.getCombo(colIndex);
	for(var i=0;i<options.length;i++){
		var option = options[i];
		combo.put(option.id, option.id + ' ' +option.name+' - <span class="desc">' +option.desc + '</span>');
	}			
}

function getStyleForRpn(val){
	var style;
	if (val<=150){
		style = 'rpn1';
	}else if (val<=250){
		style = 'rpn2';
	}else{ 
		style = 'rpn3';
	}
	
	return style;
}		

function removeRpnClasses(cell){
	var $cell = jQuery(cell);
	$cell.removeClass('rpn1');
	$cell.removeClass('rpn2');
	$cell.removeClass('rpn3');
}